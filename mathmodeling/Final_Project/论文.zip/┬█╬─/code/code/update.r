library(installr)
updateR()